var str = prompt("Digite uma string:", "");

function verificarLetraA(str) {
  var lowerStr = str.toLowerCase();
  var count = 0;

  for (var i = 0; i < lowerStr.length; i++) {
    if (lowerStr[i] === 'a') {
      count++;
    }
  }

  if (count > 0) {
    return `A letra 'a' aparece ${count} vez(es) na string.`;
  } else {
    return `A letra 'a' não aparece na string.`;
  }
}

alert(verificarLetraA(str));
