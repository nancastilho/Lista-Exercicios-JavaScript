var v1Str = prompt("Digite um número:", "");
var v1 = parseFloat(v1Str, 10);

function isFibonacci(num) {
  let fib1 = 0;
  let fib2 = 1;
  let fibNext = 0;

  if (num === 0 || num === 1) {
    return `${num} pertence à sequência de Fibonacci.`;
  }

  while (fibNext < num) {
    fibNext = fib1 + fib2;
    fib1 = fib2;
    fib2 = fibNext;
  }

  if (fibNext === num) {
    return `${num} pertence à sequência de Fibonacci.`;
  } else {
    return `${num} não pertence à sequência de Fibonacci.`;
  }
}

alert(isFibonacci(v1));
